﻿
<!DOCTYPE html>
<html lang="th">
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="content-type">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Guestbook</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sticky-footer-navbar.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>    <![endif]-->
  </head>
  <body>
    <!-- Wrap all page content here -->
    <div id="wrap">
      <!-- Fixed navbar -->
      <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header"> <span class="sr-only">Toggle navigation</span><br>
            <h1>Guestbook</h1>
          </div>
        </div>
      </div>
      <!-- Begin page content -->
      <div class="container">
        <div class="page-header">
          <div style="text-align: center; background-color: white;"><span style="font-weight: bold;">
              <a href="index.html">หน้าหลัก</a>&nbsp;&nbsp; <a href="from.html">
                เขียนข้อความ</a>&nbsp;&nbsp; อ่านข้อความ</span><br>
            <hr> </div>
          <h1>อ่านข้อความใน Guestbook</h1>
        </div>
		<?php
include("connect.php"); 
$db = new MyDB();
$result = $db->query('select * from ans');
while ($row = $result->fetchArray()){
	$id = $row['id'];
	$name = $row['name'];
	$text = $row['textarea'];
//time1 = $row['time'];
$time2 = $row['date'];
	print "<div>ข้อความที่ :".$id."<br>";
	print "<div>".$text."";
	print "<br><br>";
    print "โดย :".$name."  เวลา:".$time2."<br/>";
	print "<a href='report/index.php?idpost=".$id."'>รายงานผู้ดูแล</a>";
}
?>
<br>
        </div>
      </div>
    </div>
    <div id="footer">
      <div class="container">
        <h1> </h1>
        <p style="margin:0in;font-family:Calibri;font-size:11.0pt" lang="en-US">©
          wannaphong.com 🍀</p>
        <p style="margin:0in;font-family:Calibri;font-size:11.0pt" lang="en-US">css
          by bootstrap.</p>
      </div>
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
  </body>
</html>
