<!DOCTYPE html>
<html lang="th">
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="content-type">
    <title></title>
    <link rel="stylesheet" type="text/css" href="1.css">
  </head>
  <body>
    <div id="top">
    <h1>Guestbook</h1>
    </div>
    <p><br>
    </p>
    <div id="m"> ijo0-k96<br>
      เขียนโดย : คุณ&nbsp;&nbsp; ชื่อเล่น :&nbsp; อีเมล :&nbsp; เว็บไซต์ :&nbsp;
      <br>
    </div>
    
  </body>
</html>
