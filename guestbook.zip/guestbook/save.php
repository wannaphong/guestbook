<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
date_default_timezone_set('Asia/Bangkok'); 
include("connect.php"); 
$name = $_POST['name'];
$name2 = $_POST['name2'];
$p = $_POST['p'];
$email = $_POST['email'];
$web = $_POST['web'];
$textarea = $_POST['textarea'];
$da = $d = date("Y-m-d H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
include("tosave.php");
?>